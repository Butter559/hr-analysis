
# Home Run Analysis

This project was intended to estimate the probability of a single player having a 60+ home run season in the MLB. A large portion of the data found here is credited to StatCast, a repository of data and statistics regarding players, teams, and the league as a whole. If you would like to view the site itself, go to baseballsavant.com.

Originally, this was meant to be a project for my statistics class in college, but I would like to do more with it some time in the future.

### Contibutions
This project is not currently open to contributions. 




